from sklearn.metrics import roc_curve, auc, roc_auc_score
from sklearn.preprocessing import label_binarize
from itertools import cycle
from scipy import interp
import numpy as np
import pickle
from matplotlib import pyplot as plt

prob = pickle.load(open('pred_probs.pkl','rb'))
pred = pickle.load(open('predict_out.pkl','rb'))
label= pickle.load(open('labels_test.pkl','rb'))




probs, preds, labels = [], [], []
[probs.extend(p.flatten()) for p in prob]
probs = np.array(probs).reshape((-1,9))
[preds.extend(p.flatten()) for p in pred]
preds = np.array(preds)
[labels.extend(p.flatten()) for p in label]
labels = np.array(labels)
n_classes = 9
fpr = dict()
tpr = dict()
roc_auc = dict()
y_test = label_binarize(labels, classes=[0, 1, 2, 3, 4, 5, 6, 7, 8])
for i in range(n_classes):
    fpr[i], tpr[i], _ = roc_curve(y_test[:, i], probs[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])
fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), probs.ravel())
roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
mean_tpr = np.zeros_like(all_fpr)
for i in range(n_classes):
    mean_tpr += interp(all_fpr, fpr[i], tpr[i])
mean_tpr /= n_classes
fpr["macro"] = all_fpr
tpr["macro"] = mean_tpr
roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
plt.figure()
plt.plot(fpr["micro"], tpr["micro"],
         label='micro-average ROC curve (area = {0:0.2f})'
               ''.format(roc_auc["micro"]),
         color='deeppink', linestyle=':', linewidth=4)

plt.plot(fpr["macro"], tpr["macro"],
         label='macro-average ROC curve (area = {0:0.2f})'
               ''.format(roc_auc["macro"]),
         color='navy', linestyle=':', linewidth=4)

colors = cycle(['aqua', 'darkorange', 'cornflowerblue','pink','tan','plum','royalblue','skyblue','darkseagreen'])
for i, color in zip(range(n_classes), colors):
    plt.plot(fpr[i], tpr[i], color=color,
             label='ROC curve of class {0} (area = {1:0.2f})'
             ''.format(i, roc_auc[i]))

plt.plot([0, 1], [0, 1], 'k--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Single cell multi-class outcome')
plt.legend(loc="lower right")
plt.show()