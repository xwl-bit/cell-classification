# -*- coding: utf-8 -*-
import os
import gc
import argparse
import json
import random
import math
import pickle
import random
from functools import reduce
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.model_selection import train_test_split, ShuffleSplit, StratifiedShuffleSplit, StratifiedKFold
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, precision_recall_fscore_support, classification_report
import torch
from torch import nn
from torch.optim import Adam, SGD, AdamW
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset
from performer_pytorch import PerformerLM
import scanpy as sc
import anndata as ad
from utils import *
import pickle as pkl




parser = argparse.ArgumentParser()
parser.add_argument("--bin_num", type=int, default=5, help='Number of bins.')
parser.add_argument("--gene_num", type=int, default=17330, help='Number of genes.')
parser.add_argument("--epoch", type=int, default=100, help='Number of epochs.')
parser.add_argument("--seed", type=int, default=2022, help='Random seed.')
parser.add_argument("--novel_type", type=bool, default=False, help='Novel cell tpye exists or not.')
parser.add_argument("--unassign_thres", type=float, default=0.5, help='The confidence score threshold for novel cell type annotation.')
parser.add_argument("--pos_embed", type=bool, default=True, help='Using Gene2vec encoding or not.')
parser.add_argument("--data_path", type=str, default='/home/wangc/Downloads/data/Project/train.h5ad', help='Path of data for predicting.')
parser.add_argument("--model_path", type=str, default='./ckpts/finetuned.pth', help='Path of finetuned model.')
parser.add_argument("--batch_size", type=int, default=96, help='Number of batch size.')
args = parser.parse_args()

SEED = args.seed
EPOCHS = args.epoch
SEQ_LEN = args.gene_num + 1
UNASSIGN = args.novel_type
UNASSIGN_THRES = args.unassign_thres if UNASSIGN == True else 0
CLASS = args.bin_num + 2
POS_EMBED_USING = args.pos_embed
BATCH_SIZE = args.batch_size
device = torch.device("cuda")

class Identity(torch.nn.Module):
    def __init__(self, dropout = 0., h_dim = 100, out_dim = 10):
        super(Identity, self).__init__()
        self.conv1 = nn.Conv2d(1, 1, (1, 200))
        self.act = nn.ReLU()
        self.fc1 = nn.Linear(in_features=SEQ_LEN, out_features=512, bias=True)
        self.act1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(in_features=512, out_features=h_dim, bias=True)
        self.act2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout)
        self.fc3 = nn.Linear(in_features=h_dim, out_features=out_dim, bias=True)

    def forward(self, x):
        x = x[:,None,:,:]
        x = self.conv1(x)
        x = self.act(x)
        x = x.view(x.shape[0],-1)
        x = self.fc1(x)
        x = self.act1(x)
        x = self.dropout1(x)
        x = self.fc2(x)
        x = self.act2(x)
        x = self.dropout2(x)
        x = self.fc3(x)
        return x

class SCDataset(Dataset):
    def __init__(self, data, label):
        super().__init__()
        self.data = data
        self.label = label
    def __getitem__(self, index):
        rand_start = random.randint(0, self.data.shape[0]-1)
        full_seq = self.data[rand_start].toarray()[0]
        full_seq[full_seq > (CLASS - 2)] = CLASS - 2
        full_seq = torch.from_numpy(full_seq).long()
        full_seq = torch.cat((full_seq, torch.tensor([0]))).to(device)
        seq_label = self.label[rand_start]
        return full_seq, seq_label
    def __len__(self):
        return self.data.shape[0]

model = PerformerLM(
    num_tokens = CLASS,
    dim = 200,
    depth = 6,
    max_seq_len = SEQ_LEN,
    heads = 10,
    local_attn_heads = 0,
    g2v_position_emb = True
)
model.to_out = Identity(dropout=0., h_dim=128, out_dim=9)

file = '../train.anno.csv'
label_file = pd.read_csv(file)
label = label_file['level1'].values
data = pickle.load(open('train_valid.pkl','rb'))
data_temp, data_val, y_temp, y_val = train_test_split(data, label, test_size=0.2,random_state=2022)
data_train, data_test, y_train, y_test = train_test_split(data_temp, y_temp, test_size=0.25,random_state=2022)
labels_dict_test, labels_test = np.unique(y_test, return_inverse=True)

test_dataset = SCDataset(data_test, labels_test)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE)


model=torch.load('/home/wangc/Downloads/data/Project/scBERT/ckpts/finetune_wd_best.pth')
ckpt=torch.load('/home/wangc/Downloads/data/Project/scBERT/ckpts/finetune_best.pth')
for param in model.parameters():
    param.requires_grad = False
model = model.to(device)
model.load_state_dict(ckpt['model_state_dict'])
batch_size = data_test.shape[0]
model.eval()
pred_finals = []
labels_finals = []
pred_probs = []
with torch.no_grad():
    for index, (data, labels) in enumerate(test_loader):
        data, labels = data.to(device), labels.to(device)
        logits = model(data)
        softmax = nn.Softmax(dim=-1)
        pred_prob = softmax(logits)
        pred_probs.append(pred_prob)
        pred_final = pred_prob.argmax(dim=-1)
        pred_finals.append(pred_final)
        labels_finals.append(labels)
        print(f' == Index {index} | {len(test_dataset)/BATCH_SIZE}')


pred_finals = np.array([p.cpu().numpy() for p in pred_finals]).flatten()
labels_test = np.array([p.cpu().numpy() for p in labels_finals]).flatten()
pred_probs = np.array([p.cpu().numpy() for p in pred_probs]).flatten()

import pickle
pickle.dump(pred_finals, open('predict_out.pkl','wb'))
pickle.dump(labels_test, open('labels_test.pkl','wb'))
pickle.dump(pred_probs, open('pred_probs.pkl','wb'))
cur_acc = accuracy_score(labels_test, pred_finals)
f1 = f1_score(labels_test, pred_finals, average='macro')
print(cur_acc, f1)
#0.957965
#0.82223007865
