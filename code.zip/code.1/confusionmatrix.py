from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

y_pred = [1,0,0,1,0,1,0,1,0,1,0,1,1,0,0] # ['2','2','3','1','4'] # 类似的格式
y_true = [0,0,0,1,0,0,0,1,0,1,0,1,0,0,1] # ['0','1','2','3','4'] # 类似的格式


#y_pred = y_pred.replace(0,"Early cancer")

y_pred = ["Early" if a == 0 else "Advanced" for a in y_pred]
y_true = ["Early" if a == 0 else "Advanced" for a in y_true]




# 对上面进行赋值

C = confusion_matrix(y_true, y_pred, labels=["Early","Advanced"]) # 可将'1'等替换成自己的类别，如'cat'。

plt.figure(figsize=(6, 6), dpi=500)
#plt.subplots_adjust(left=10, bottom=10, right=20, top=20, wspace=None, hspace=None)
plt.subplots_adjust(left=10,right=20)
plt.matshow(C, cmap=plt.cm.Reds) # 根据最下面的图按自己需求更改颜色
# plt.colorbar()

for i in range(len(C)):
	for j in range(len(C)):
		plt.annotate(C[j, i], xy=(i, j), horizontalalignment='center', verticalalignment='center')

# plt.tick_params(labelsize=15) # 设置左边和上面的label类别如0,1,2,3,4的字体大小。

plt.ylabel('True label',labelpad=12)
plt.xlabel('Predicted label',labelpad=12)
plt.ylabel('True label', fontdict={'size': 16}) # 设置字体大小。
plt.xlabel('Predicted label', fontdict={'size': 16})
plt.xticks(range(0,2), labels=['Early','Advanced']) # 将x轴或y轴坐标，刻度 替换为文字/字符
plt.yticks(range(0,2), labels=['Early','Advanced'])
#plt.xticks(rotation=0)
plt.yticks(rotation=90)
plt.show()
plt.savefig("confusionmatrix.for.neuralnetwork.png")
